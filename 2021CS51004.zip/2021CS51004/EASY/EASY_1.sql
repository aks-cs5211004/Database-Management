select count(*) from patients where patients.anchor_age between 18 and 30 ;


;