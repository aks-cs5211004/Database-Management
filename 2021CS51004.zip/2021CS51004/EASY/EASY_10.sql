
with 
temp2 as (
select subject_id, anchor_age, icd_code, icd_version from 
patients join admissions using (subject_id) join procedures_icd
using (subject_id, hadm_id)
where anchor_age<50
group by subject_id, anchor_age, icd_code, icd_version
having count(distinct hadm_id)>1)

select distinct subject_id, anchor_age from 
temp2
order by subject_id, anchor_age
