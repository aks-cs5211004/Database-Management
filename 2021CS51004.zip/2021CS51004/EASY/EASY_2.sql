select subject_id, count(distinct hadm_id) as num_admissions 
from admissions 

group by subject_id 

having count(distinct hadm_id) =

(select count(distinct hadm_id) as num_admissions 
from admissions 
group by subject_id 
order by count(subject_id) desc
limit 1)


order by subject_id

;