select count(distinct labevent_id)
from labevents where priority = 'ROUTINE' and flag ='abnormal'



;