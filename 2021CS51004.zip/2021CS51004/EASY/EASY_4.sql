select count(*) from (
select distinct icd_code,icd_version
from procedures_icd 
where subject_id=10000117) d


;