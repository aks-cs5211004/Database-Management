
select subject_id, anchor_age, count (first_careunit)
from patients join icustays using (subject_id)
where first_careunit='Coronary Care Unit (CCU)'
group by subject_id , anchor_age

having count (first_careunit) = 
(select count (first_careunit)
from patients join icustays using (subject_id)
where first_careunit='Coronary Care Unit (CCU)'
group by subject_id , anchor_age
order by count (first_careunit) desc , anchor_age desc, subject_id desc limit 1)

order by anchor_age desc, subject_id desc



;