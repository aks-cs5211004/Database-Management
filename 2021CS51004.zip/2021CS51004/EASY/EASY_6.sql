select count(distinct hadm_id)
from diagnoses_icd join d_icd_diagnoses
using (icd_code, icd_version)

where long_title = 'Cholera due to vibrio cholerae'
group by icd_code, icd_version




;