select distinct subject_id, anchor_age from 
(
select d.subject_id from 
(diagnoses_icd d join d_icd_diagnoses using (icd_code,icd_version)) 
join 
icustays using (subject_id, hadm_id) where stay_id is not null
and long_title = 'Typhoid fever'
) s
join patients using (subject_id)

order by subject_id asc, anchor_age asc



;