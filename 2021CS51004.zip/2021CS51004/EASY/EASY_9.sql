select count(distinct hadm_id) from admissions a join labevents l 
using (hadm_id, subject_id) 
where a.hospital_expire_flag=1 and l.flag='abnormal'


;