with  latest_admission as (
  select distinct subject_id, gender, hadm_id, hospital_expire_flag from 
 (select p.subject_id, p.gender,max(a.admittime) latest_adm
  from admissions a join patients p
  using (subject_id)
  group by p.subject_id, p.gender) s
 join admissions
 using (subject_id)
 where admittime=latest_adm
),

diagnosis_info as (
  select distinct a.icd_code, a.icd_version, a.hadm_id, a.subject_id
  from diagnoses_icd a join d_icd_diagnoses b
  using (icd_code, icd_version)
  where b.long_title like '%Meningitis%'
),

total_count as (
select gender, count(*) as total  from (
select distinct subject_id, gender from
latest_admission join diagnosis_info
using (subject_id, hadm_id)) t
group by gender
) 


select gender, ROUND((per::numeric/total::numeric)*100, 2) as mortality_rate
from(


(select gender, count(*) as per  from (
select distinct subject_id, gender from
latest_admission join diagnosis_info
using (subject_id, hadm_id)
where hospital_expire_flag=1) l
group by gender) u
join 
total_count using(gender)

)

d
order by mortality_rate asc , gender desc

;

