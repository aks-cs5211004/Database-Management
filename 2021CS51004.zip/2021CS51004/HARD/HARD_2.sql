with diagnoses as(
    select distinct icd_code, icd_version, hadm_id, long_title
    from  diagnoses_icd join d_icd_diagnoses
    using (icd_code, icd_version)
    where hadm_id is not null and icd_code is not null and long_title is not null
    and icd_version is not null
),
info as(
    select distinct anchor_age, subject_id, hadm_id, hospital_expire_flag from 
    patients join admissions
    using (subject_id)
),
temp as(
    select icd_code, icd_version, long_title, x::numeric/ y::numeric as mortality_rate from(
    select  icd_code,icd_version,sum(hospital_expire_flag) as x,count(distinct hadm_id) as y,long_title
    from 
    diagnoses join info
    using (hadm_id)
    group by icd_code, icd_version,long_title) as s
    order by mortality_rate desc
    limit 245)

select long_title, ROUND(avg(anchor_age),2) as survived_anchor_age from

(select distinct icd_code,icd_version, long_title, subject_id, anchor_age from 
((temp join diagnoses_icd
using (icd_code,icd_version))
join admissions using (hadm_id, subject_id)) join patients using (subject_id)
group by icd_code, icd_version, long_title, subject_id, anchor_age
having sum(hospital_expire_flag)=0) as p

group by icd_code, icd_version, long_title
order by long_title asc, survived_anchor_age desc;