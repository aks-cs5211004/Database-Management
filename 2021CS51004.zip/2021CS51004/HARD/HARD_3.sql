with temp as (
    select distinct subject_id,hadm_id, stay_id, 
    COALESCE(los, 0.0) as x
    from procedures_icd a left join icustays b using (subject_id, hadm_id)
   ),
temp0 as (
    select distinct hadm_id, subject_id, sum(x) as j
    from temp
    group by hadm_id, subject_id
),
temp2 as (
    select distinct icd_code, icd_version, hadm_id, subject_id ,j  from 
    temp0
    join 
    procedures_icd
    using (hadm_id,subject_id)
),
temp1 as (
    select distinct icd_code, icd_version, avg(j) as z from 
    temp2
    group by icd_code, icd_version
)
select distinct subject_id, gender ,icd_code, icd_version from 
temp2 join patients using (subject_id) join 
temp1 using (icd_code, icd_version) 
where j<z
order by subject_id asc, gender asc , icd_code desc, icd_version desc


limit 1000;

