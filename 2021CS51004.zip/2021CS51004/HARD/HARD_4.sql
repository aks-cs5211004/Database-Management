
create view   nodes as 
    
    select distinct subject_id , hadm_id, admittime, dischtime, icd_code, icd_version, long_title from 
    (select distinct subject_id , hadm_id, admittime, dischtime, icd_code, icd_version from 
    (select distinct subject_id , hadm_id, admittime, dischtime from 
    (select distinct hadm_id, admittime, dischtime
    from admissions 
    order by admittime asc
    limit 500) a join admissions b using (hadm_id, admittime, dischtime)) j
    join diagnoses_icd
    
    using (subject_id, hadm_id)) u join d_icd_diagnoses using (icd_code, icd_version)
    where admittime<=dischtime
;

create view edges as
    select * from 
    (SELECT
    DISTINCT
    t1.subject_id x,t2.subject_id y
    FROM
        nodes t1
    JOIN
        nodes t2
    ON NOT ((t1.admittime > t2.dischtime and t2.admittime < t1.dischtime ) 
            OR (t1.dischtime < t2.admittime and t1.admittime < t2.dischtime )
            ) 
    where t1.icd_code=t2.icd_code and t1.icd_version=t2.icd_version and t1.long_title = t2.long_title
     ) s
    where x<>y
;



WITH RECURSIVE PathCTE AS (
    SELECT
        x AS start_node,
        y AS end_node,
        ARRAY[x, y] AS path,
        1 AS path_length
    FROM
        edges
    WHERE
        x = 18237734 AND y <> 18237734
    
    UNION ALL
    
    SELECT
        e.x AS start_node,
        e.y AS end_node,
        path || e.y AS path,
        path_length + 1 AS path_length
    FROM
        PathCTE p
    JOIN
        edges e ON (p.end_node = e.x and e.y <> p.start_node)
    WHERE
        path_length < 3
)
SELECT
    EXISTS (
        SELECT *
        FROM PathCTE
        WHERE end_node = 13401124 AND path_length = 3
    ) AS pathexists;



drop view nodes, edges;