
select distinct subject_id, count(distinct stay_id)  from
icustays 

group by subject_id 
HAVING count(distinct stay_id)>4 
order by count(distinct stay_id) DESC, subject_id DESC 

limit 1000;