select distinct x.subject_id,y.anchor_year,x.drug from

(select distinct subject_id, drug, count(distinct hadm_id)
from 
prescriptions 
where hadm_id is not null
and drug is not null
group by subject_id, drug
having count(distinct hadm_id)>1) x
join
patients y
using(subject_id)

order by x.subject_id desc,y.anchor_year desc, x.drug desc


;