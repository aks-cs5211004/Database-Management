
select distinct drug, count(hadm_id) as prescription_count from
prescriptions p join admissions a using (hadm_id, subject_id)
where EXTRACT (EPOCH from(p.starttime - a.admittime))<12*60*60+1 and
EXTRACT (EPOCH from (p.starttime - a.admittime))>-1
and hadm_id is not null
group by drug
order by prescription_count DESC, drug DESC
limit 1000;