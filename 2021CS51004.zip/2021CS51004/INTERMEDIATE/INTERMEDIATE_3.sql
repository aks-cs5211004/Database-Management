
select subject_id, count(distinct description) as diagnoses_count from drgcodes 
where description ilike '%ALCOHOLIC%'

group by subject_id
having  count(distinct hadm_id) >1

order by diagnoses_count desc, subject_id desc
;