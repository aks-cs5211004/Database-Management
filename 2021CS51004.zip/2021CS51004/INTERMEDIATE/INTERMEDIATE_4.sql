select distinct x.subject_id, x.hadm_id, x.icd_code, y.long_title
from 
(select distinct a.subject_id, a.hadm_id, d.icd_code, d.icd_version
from admissions a join diagnoses_icd d
using (subject_id, hadm_id)
where a.admission_type='URGENT'
and a.hospital_expire_flag=1) x
join 
d_icd_diagnoses y
using (icd_code, icd_version)
where y.long_title is not null
order by x.subject_id desc,x.hadm_id desc, x.icd_code desc, y.long_title desc
limit 1000
