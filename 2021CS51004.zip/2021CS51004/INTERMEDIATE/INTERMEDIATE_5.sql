select distinct subject_id, sa as avg_stay_duration from 

(select distinct s.subject_id, s.hadm_id, avg(s.los) as sa from 
(select c.subject_id, c.los, c.hadm_id
from icustays c join labevents l 
using (subject_id, hadm_id)
where l.itemid=50878 
and c.los is not null
and c.subject_id is not null
and c.hadm_id is not null) as s
group by s.subject_id, s.hadm_id) as si

order by avg_stay_duration desc, subject_id desc
