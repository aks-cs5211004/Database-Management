select distinct subject_id,gender, total_admisssions,last_admission, first_admission, diagnosis_count from 
(
select a.subject_id, a.total_admisssions, a.last_admission, a.first_admission, count(distinct b.hadm_id) as diagnosis_count
from 
(
     select distinct  z.subject_id, count(distinct z.hadm_id) as total_admisssions, MAX(z.admittime) as last_admission, 
     MIN(z.admittime) as first_admission
     from 
     (
     (select distinct subject_id from diagnoses_icd where icd_code='5723' and hadm_id is not null) x
     join 
     admissions y 
     using (subject_id)
     ) z
     group by z.subject_id
) a
join 
diagnoses_icd b
using(subject_id)
where b.icd_code='5723'
group by a.subject_id, a.total_admisssions, a.last_admission, a.first_admission
having count(distinct b.hadm_id)>0
) c

join patients
using (subject_id)

order by total_admisssions desc, diagnosis_count desc, last_admission desc, first_admission desc, gender desc, subject_id desc





limit 1000