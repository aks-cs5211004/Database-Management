
select distinct subject_id,count(distinct stay_id) as total_stays,avg(los) as avg_length_of_stay
from icustays
where first_careunit like '%MICU%' or last_careunit like '%MICU%'
group by subject_id
having count(distinct stay_id)>4


order by avg_length_of_stay desc, total_stays desc , subject_id desc 

limit 500
