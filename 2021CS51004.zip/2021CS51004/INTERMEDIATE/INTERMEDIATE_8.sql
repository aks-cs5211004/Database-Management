select distinct a.subject_id,a.hadm_id, count(distinct icd_code) as distinct_diagnoses_count,b.drug
from 
diagnoses_icd a join prescriptions b
using (subject_id, hadm_id)
where a.icd_code like 'V4%' and (b.drug ilike '%prochlorperazine%' or b.drug ilike '%bupropion%') 
group by subject_id, hadm_id, drug 
having count(distinct icd_code)>1
order by distinct_diagnoses_count desc, subject_id desc, hadm_id desc, drug asc
;