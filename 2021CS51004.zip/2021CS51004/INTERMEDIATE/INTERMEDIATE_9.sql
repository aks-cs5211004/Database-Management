with temp1 as (
                select subject_id, hadm_id as fid,admittime as fadm, dischtime as fdis
                from admissions join diagnoses_icd
                using (subject_id, hadm_id)
                where icd_code like 'I21%'
),

temp2 as (
    select subject_id from
    admissions join temp1 using (subject_id)
    where admittime > fadm
    and  admittime > fdis
)
select distinct *  from
temp2
order by subject_id desc
limit 1000
;